<?php
session_start();
include "koneksi.php";
if (isset($_SESSION["username"]) && !empty($_SESSION ["username"])) {
    $username = $_SESSION["username"];
} else {
    header ("location: index.php");
}
?>
Selamat Datang <?= $username ?>
<br>
Peminjaman Buku

<link rel="stylesheet" type="text/css" media="screen" href="text.css">

<br> <br>
<a href = "tambah.php" >Tambah Baru</a>
<br>
<a href = "keluar.php" >keluar</a>

<table>
<thead>
<th> anggota </th>
<th> buku </th>
<th> status </th>

</thead>
<tbody>
<?php
$query = "SELECT * FROM peminjaman-buku";
$result = $conn->query($query);
$i = 1;

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) { ?>
    <tr>
    <td><?= $i; ?></td>
    <td><?= $row["anggota"]; ?></td>
    <td><?= $row["buku"]; ?></td>
    
    
    <td>
    <a href="hapus.php?no=<?= $row
    ['no']; ?>">hapus</a>
    <a href="edit.php?no=<?= $row['no']; ?>">edit</a>

    </td>
    </tr>
    <?php $i++;
    }
}
?>

<?php if(isset($_GET['status'])): ?>
<p>
    <?php
    if($_GET['status'] == 'sukses'){
        echo "Penambahan kegiatan baru berhasil";
    } else {
        echo "Penambahan gagal";
    }
    ?>
    </p>
<?php endif; ?>
</tbody>
</table>