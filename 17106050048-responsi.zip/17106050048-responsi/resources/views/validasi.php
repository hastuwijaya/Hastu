<?php
session_start();
include "koneksi.php";


// cara menguji apakah name="username" bisa diambil nilainya engga dengan cara pakai var_dump
// var_dump($_POST["username"]); //var_dump biasanya dipake buat nguji 
// die();

$username = $_POST["username"];
$password = $_POST["password"];


$query = mysqli_query($conn, "SELECT * FROM users WHERE
username='$username' AND password='$password'");
// cara bacanya mengambil(select) semua(*) dari (from) tabel login dimana(where) username = $username' dan(AND) password='$password';

if ($data = mysqli_num_rows($query) > 0) {
    $_SESSION["username"] = $username;
    header ("location: beranda.php");
} else {
    header ("location: index.php");
}
?>
