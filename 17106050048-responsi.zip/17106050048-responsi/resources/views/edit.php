<?php
session_start();
include "koneksi.php";
if (isset($_SESSION["username"]) && !empty($_SESSION ["username"])) {
    $username = $_SESSION["username"];
} else {
    header ("location: index.php");
}
?>

<?php

include("koneksi.php");

//kalau tidak ada id di query string
if( !isset($_GET['no']) ){
    header('Location: beranda.php');
}
// var_dump($_GET['no']);
// die();

// metode untuk ambil itu ada post sama get
// kalau post itu ada dibelakang layar(gak kelihatan)
// kalau get itu ada diurl

//ambil id dari query string
$id = $_GET['no'];

//buat query untuk ambil data dari database
$sql = "SELECT * FROM peminjaman-buku WHERE no=$id";
$query = mysqli_query($conn, $sql);
$result = mysqli_fetch_assoc($query);
// var_dump($result['kegiatan']);
// die();

//jika data yang di-edit tidak ditemukan
// if( mysqli_num_rows($result) == 1 ){
//     die("data tidak ditemukan...");
// } 

// kalau mau ngedit,kita harus tentuin yang mana yang mau diedit, cara nenutinnya dilihat dari id/no
?>

<!DOCTYPE html>
<html>
<link rel="stylesheet" type="text/css" media="screen" href="text.css">
    <head>
        <title> Peminjaman buku | Perpustakaan Bobo </title>
</head>

<body>
    <header>
        <h3>Peminjaman Baru</h3>
</header>

<form action="proses-edit.php" method="POST">

<fieldset>
    
    <p>
        <!-- bikin inputan yang ga kelihatan untuk id, kenapa ga kelihatan biar ga bisa dieit sama otang lain -->
        <!-- pakai atribut type = hidden -->
        <input type="hidden" name="no" value="<?php echo $result['no'];?>" >

        <label for="anggota">No Anggota : </label>
        <input type="text" name="anggota" placeholder="No Anggota" value="<?php echo $result['anggota'];?>" />
<!-- ada atribut value gunanya untuk memberikan nilai -->
</p>
<p>
    <label for="judulbuku">Judul buku: </label>
    <input type="text" name="judulbuku" placeholder="Desc Buku" value="<?php echo $result['judulbuku'];?>"/>
</p>
<p>
    <input type="submit" value="submit" name="submit"/>
</p>
</fieldset>
</form>
</body>
<html>