<?php
session_start();
include "koneksi.php";
if (isset($_SESSION["username"]) && !empty($_SESSION ["username"])) {
    $username = $_SESSION["username"];
} else {
    header ("location: index.php");
}
?>

<?php
include("koneksi.php");

if( isset($_GET['no']) ){
    //ambil no dari query string
    $no = $_GET['no'];

    //buat query hapus
    $sql = "DELETE FROM peminjaman-buku WHERE no=$no";
    $query = mysqli_query($conn, $sql);

    //apakah query hapus berhasil?
    if( $query) {
        header('Location: beranda.php');
    } else {
        die("gagal menghapus...");
    }
    
}
?>

<!-- session itu brfungsi untuk menandai sesi aktif/tidak kalau admin yaa dia admin/bukan -->
