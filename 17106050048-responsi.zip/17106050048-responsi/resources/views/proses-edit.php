<?php
session_start();
include "koneksi.php";
if (isset($_SESSION["username"]) && !empty($_SESSION ["username"])) {
    $username = $_SESSION["username"];
} else {
    header ("location: index.php");
}
?>


<?php
include("koneksi.php");

//cek apakah tombol daftar sudah diklik atau belum?
if(isset($_POST['submit'])){
    
    //ambil data dari formulir
    $no = $_POST['anggota'];
    $profile = $_POST['buku'];
    $kegiatan = $_POST['status'];

    // var_dump($buku,$status);
    // die();
  
    // Edit menggunakan perintah UPDATE
    // cara baca perbarui (UPDATE) tabel peminjaman-buku ganti(SET) buku dengan $buku bukun yang dipinjami(WHERE) no = $no
    $sql = "UPDATE peminjaman-buku SET buku = '$buku', status = '$status' WHERE no='$no'" ;


   //cara baca tambah(insert) ke(into) peminjaman-buku ()
    $query = mysqli_query($conn, $sql);
    // var_dump($query);
    // die();

    //apakah query simpan berhasil?
    if( $query){
        //kalau berhasil alihkan ke halaman index.php dengan status=sukses
        header('Location: beranda.php?status=sukses');
    } else {
        //kalau gagal alihkan ke halaman index.php dengan status=gagal
        header('Location: beranda.php?status=gagal');
    }
    
}
?>