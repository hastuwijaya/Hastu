<?php
session_start();
include "koneksi.php";
if (isset($_SESSION["username"]) && !empty($_SESSION ["username"])) {
    $username = $_SESSION["username"];
} else {
    header ("location: index.php");
}
?>

<!DOCTYPE html>
<html>
<link rel="stylesheet" type="text/css" media="screen" href="text.css">
    <head>
        <title> Peminjaman Buku Baru | Perpustakaan Bobo </title>
</head>

<body>
    <header>
        <h3>peminjaman buku baru</h3>
</header>

<form action="proses-penambahan.php" method="POST">

<fieldset>
    <p>
        <label for="buku">Buku : </label>
        <input type="text" name="buku" placeholder="Judul Buku"/>

</p>
<p>
    <label for="buku">Judul Buku: </label>
    <input type="text" name="status" placeholder="Desc Buku"/>
</p>
<p>
    <input type="submit" value="submit" name="submit"/>
</p>
</fieldset>
</form>
</body>
<html>