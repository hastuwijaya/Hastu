<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Mahasiswa;

class MahasiswaController extends Controller
{
    //
    public function index()
    {
        $mahasiswas = Mahasiswa::all();
        return view('', [
            'mahasiswas' => $mahasiswas
        ]);
    }

    public function show($id)
    {
        $mahasiswa = Mahasiswa::findOrFail($id);
        return view('', [
            'mahasiswa' => $mahasiswa
        ]);
    }

    public function store(Request $request)
    {
        Mahasiswa::create([
            'nim' => $request->nim,
            'nama' => $request->nama,
            'kode_prodi' => $request->kode_prodi,
            'alamat' => $request->alamat
        ]);
        
        return view('');
    }

    public function update(Request $request, $id)
    {
        Mahasiswa::find($id)->update([
            'nim' => $request->nim,
            'nama' => $request->nama,
            'kode_prodi' => $request->kode_prodi,
            'alamat' => $request->alamat
        ]);
        return view('');
    }

    public function delete($id)
    {
        Mahasiswa::find($id)->delete();
    }
}
