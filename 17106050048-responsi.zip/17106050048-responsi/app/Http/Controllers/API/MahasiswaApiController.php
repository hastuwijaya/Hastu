<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Mahasiswa;
use App\Http\Controllers\Controller;

class MahasiswaApiController extends Controller
{
    public function index()
    {
        $mahasiswas = Mahasiswa::all();
        if ($mahasiswas) {
            return response()->json([
                'success' => true,
                'data' => $mahasiswas,
                'message' => 'Mahasiswas retrieved successfully'
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Mahasiswa is empty'
            ]);
        }
    }

    public function show($nim)
    {
        $mahasiswa = Mahasiswa::where('nim', $nim)->first();
        if ($mahasiswa) {
            return response()->json([
                'success' => true,
                'data' => $mahasiswa,
                'message' => 'Mahasiswa retrieved successfully'
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Mahasiswa not found'
            ]);
        }
    }

    public function store(Request $request)
    {
        $mahasiswa = Mahasiswa::create([
            'nim' => $request->nim,
            'nama' => $request->nama,
            'kode_prodi' => $request->kode_prodi,
            'alamat' => $request->alamat
        ]);
        
        if ($mahasiswa) {
            return response()->json([
                'success' => true,
                'message' => 'Mahasiswa add successfully'
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Mahasiswa add unsuccessfully'
            ]);
        }
    }

    public function update(Request $request, $nim)
    {
        $mahasiswa = Mahasiswa::where('nim', $nim)->update([
            'nama' => $request->nama,
            'kode_prodi' => $request->kode_prodi,
            'alamat' => $request->alamat
        ]);
        
        if ($mahasiswa) {
            return response()->json([
                'success' => true,
                'message' => 'Mahasiswa update successfully'
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Mahasiswa update unsuccessfully.'
            ]);
        }
    }

    public function delete($nim)
    {
        $mahasiswa = Mahasiswa::where('nim', $nim)->delete();
        return response()->json([
            'success' => true,
            'message' => 'Mahasiswa deleted successfully'
        ]);
    }
}
