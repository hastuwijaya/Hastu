<?php

use Illuminate\Database\Seeder;
use App\Models\Mahasiswa;
use Illuminate\Support\Str;

class MahasiswaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for ($i=0; $i < 10; $i++) { 
            Mahasiswa::create([
                'nim' => '191060500' + $i,
                'nama' => Str::random(10),
                'kode_prodi' => '05',
                'alamat' => 'Yogya'
            ]);
        }
    }
}
